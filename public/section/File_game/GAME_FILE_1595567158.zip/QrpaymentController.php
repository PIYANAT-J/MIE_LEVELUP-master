<?php

namespace App\Http\Controllers\api\v1\payment;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Merchant;
use App\Qrpayment;

class QrpaymentController extends Controller
{
    public function requestqrcode(Request $request)
    {
        $data = request()->validate([
            'token'=> 'required',
            'amount'=> 'required',
        ]);
        
        $check_token =  Merchant::where('token', $data['token'])->first();
        

        if(!$check_token) {
            return response(['message' => 'Invalid login credentials.'],401);
        }

        $merchant = $check_token->get()->first();

        $qrpayment = new Qrpayment();
        $qrpayment->merchant_id = $merchant->id;
        $qrpayment->qrType = "qr30";
        $qrpayment->amount = $data["amount"];
        $qrpayment->note = $request->note;
        $qrpayment->blockchain = "###multiinovation###";
        $qrpayment->save();
        $ref_id = "SCBQRPAYMENT".sprintf("%05d",$qrpayment->id);
        $ref1 = $ref_id;
        $ref2 = "REFERENCE2";
        $ref3 = "SCB";

        try {
            $qrcode = $this->getQrcode($data["amount"] , $request->note , $ref1 , $ref2 , $ref3);
        } catch (\Throwable $th) {
            return response(['message' => 'Somethings wrong !.'],401);
        }

        $qrpayment = Qrpayment::find($qrpayment->id);
        $qrpayment->rawQrCode = $qrcode->data->qrRawData;
        $qrpayment->invoice = $ref_id;
        $qrpayment->save();

        return response(['rawQrCode' => $qrcode->data->qrRawData , 'invoice' => $ref_id]);        
        
    }


    public function getQrcode($amount , $note , $ref1 , $ref2 , $ref3)
    {


        $register = $this->getToken();
        $accessToken = ($register->status->code == "1000")? $register->data->accessToken:'';

        $qrType = "PP";
        $ppType = "BILLERID";
        $ppId = env('SCB_PPID');
        $headers = [
            'Content-Type' => 'application/json',
            'authorization' => 'Bearer '.$accessToken,
            'requestUId' => 't10assets Api v1',
            'resourceOwnerId' => env('SCB_APPLICATIONKEY'),
            'accept-language' => 'EN',
            ];
    
        $client = new \GuzzleHttp\Client();
        $response = $client->request('POST', env('SCB_APP_CREATE_QR30_URL'), [
            'headers' => $headers,
            'json' => [
                "qrType" => $qrType,
                "ppType" => $ppType,
                "ppId" => $ppId,
                "amount" => $amount,
                "ref1" => $ref1,
                "ref2" => $ref2,
                "ref3" => $ref3,
            ]
        ]);

        $http_status_code = $response->getStatusCode();
        $response->getHeaderLine('content-type');
        $response->getBody();
        $contents = json_decode($response->getBody());

        return ($http_status_code == 200)? $contents:'';
    }


    public function getToken()
    {

        $headers = [
            'Content-Type' => 'application/json',
            'requestUId' => 't10assets Api v1',
            'resourceOwnerId' => env('SCB_APPLICATIONKEY'),
            'accept-language' => 'EN',
            ];
    
            $client = new \GuzzleHttp\Client();
            $response = $client->request('POST', env('SCB_APP_REQUEST_TOKEN_URL'), [
                'headers' => $headers,
                'json' => [
                    "applicationKey" => env('SCB_APPLICATIONKEY'),
                    "applicationSecret" => env('SCB_APPLICATIONSECRET'),
                ]
            ]);
    
            $http_status_code = $response->getStatusCode();
            $response->getHeaderLine('content-type');
            $response->getBody();
            $contents = json_decode($response->getBody());
    
            return ($http_status_code == 200)? $contents:'';
    }
}
