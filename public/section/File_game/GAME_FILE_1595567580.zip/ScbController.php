<?php

namespace App\Http\Controllers\topup;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Mobiletopup;
use Auth;
use \Milon\Barcode\DNS2D;
use Illuminate\Support\Str;

class ScbController extends Controller
{
    public function index()
    {
        $transaction = \App\Mobiletopup::where('user_id',Auth::user()->id)
        ->orderBy('created_at', 'desc')
        ->limit(5)
        ->get();
    
        foreach($transaction as $item){
            $item->difftime = \Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $item['created_at'])->diffInMinutes(\Carbon\Carbon::now());
            if($item->difftime > 15 && $item->status == 0){
                $item->status = 99;
                // expire
            }
        }

        return view('topup.scbmobilebanking',compact('transaction'));
    }

    public function qrcode($invoice = null)
    {
        $mobiletopup = Mobiletopup::Where('invoice', decrypt($invoice))->get()->first();

        $invoice =  DNS2D::getBarcodeHTML($mobiletopup->rawQrCode, "QRCODE");
        $invoice = $mobiletopup->rawQrCode;
        return view('topup.qrcode', compact('invoice'));
    }


    public function mobilebanking(Request $request)
    {
        $register = $this->getToken();
        $mobiletopup = new Mobiletopup();
        $mobiletopup->user_id = Auth::user()->id;
        $mobiletopup->qrType = "PP";
        $mobiletopup->partner = env('SCB_PARTNER_NAME');
        $mobiletopup->ppType = "BILLERID";
        $mobiletopup->ppId = env('SCB_PPID');
        $mobiletopup->amount = $request->amount;
        $mobiletopup->note = $request->note;
        $mobiletopup->blockchain = "###TOPUP-MULTI###";
        $mobiletopup->save();

        $ref_id = "SCB".sprintf("%05d",$mobiletopup->id);
        $ref1 = $ref_id;
        $ref2 = "REFERENCE2";
        $ref3 = "SCB";
        $accessToken = ($register->status->code == "1000")? $register->data->accessToken:'';
        $qrcode = ($accessToken != '')? $this->getQrcode($accessToken ,
                                            $mobiletopup->qrType, 
                                            $mobiletopup->ppType, 
                                            $mobiletopup->ppId, 
                                            $mobiletopup->amount, 
                                            $ref_id,
                                            $ref1,
                                            $ref2,
                                            $ref3
                                            ):'';
       
        $mobiletopup = Mobiletopup::find($mobiletopup->id);
        $mobiletopup->rawQrCode = $qrcode->data->qrRawData;
        $mobiletopup->ref_id = sprintf("%05d",$mobiletopup->id);
        $mobiletopup->invoice = $ref_id;
        $mobiletopup->ref1 = $ref_id;
        $mobiletopup->ref2 = $ref2;
        $mobiletopup->ref3 = $ref3;
        $mobiletopup->save();

        return redirect(route('topup.qrcode.scb', ['invoice' => encrypt($ref_id)]));
    }

    public function getQrcode($accessToken = null, $qrType = null, $ppType, $ppId = null, $amount = null, $ref_id = null, $ref1 = null, $ref2 = null, $ref3 = null)
    {
        $headers = [
            'Content-Type' => 'application/json',
            'authorization' => 'Bearer '.$accessToken,
            'requestUId' => 't10assets Api v1',
            'resourceOwnerId' => env('SCB_APPLICATIONKEY'),
            'accept-language' => 'EN',
            ];
    
        $client = new \GuzzleHttp\Client();
        $response = $client->request('POST', env('SCB_APP_CREATE_QR30_URL'), [
            'headers' => $headers,
            'json' => [
                "qrType" => $qrType,
                "ppType" => $ppType,
                "ppId" => $ppId,
                "amount" => $amount,
                "ref1" => $ref1,
                "ref2" => $ref2,
                "ref3" => $ref3,
            ]
        ]);

        $http_status_code = $response->getStatusCode();
        $response->getHeaderLine('content-type');
        $response->getBody();
        $contents = json_decode($response->getBody());

        return ($http_status_code == 200)? $contents:'';
    }

    public function getToken()
    {
        $headers = [
        'Content-Type' => 'application/json',
        'requestUId' => 't10assets Api v1',
        'resourceOwnerId' => env('SCB_APPLICATIONKEY'),
        'accept-language' => 'EN',
        ];

        $client = new \GuzzleHttp\Client();
        $response = $client->request('POST', env('SCB_APP_REQUEST_TOKEN_URL'), [
            'headers' => $headers,
            'json' => [
                "applicationKey" => env('SCB_APPLICATIONKEY'),
                "applicationSecret" => env('SCB_APPLICATIONSECRET'),
            ]
        ]);

        $http_status_code = $response->getStatusCode();
        $response->getHeaderLine('content-type');
        $response->getBody();
        $contents = json_decode($response->getBody());

        return ($http_status_code == 200)? $contents:'';
    }
}
