<?php
 
    require_once __DIR__.'/config/connectpdo.php'; 

   $error  = array();
   $res    = array();

        
        if(empty($_POST['MEM_EMAIL']))
        {
            $error[] = "Email field is required";    
        }
    
        if(empty($_POST['MEM_PASSWORD']))
        {
            $error[] = "Password field is required";    
        }
        if (!empty($_POST['MEM_EMAIL']) && !filter_var($_POST['MEM_EMAIL'], FILTER_VALIDATE_EMAIL)) {
            $error[] = "Enter Valid Email address";
        } 
         
        if(count($error)>0)
        {
            $resp['msg']    = $error;
            $resp['MEM_STATUS'] = false;    
            echo json_encode($resp);
            exit;
        }

        $sql = "SELECT * FROM MIE_MEMBER WHERE MEM_EMAIL = :MEM_EMAIL";
        $stmt=$db->prepare($sql);
        $stmt->execute(array(':MEM_EMAIL' => $_POST['MEM_EMAIL']));
        $row = $stmt->fetchAll(PDO::FETCH_ASSOC);
        if(count($row)>0) {
           if(!password_verify($_POST['MEM_PASSWORD'],$row[0]['MEM_PASSWORD'])) {
                $error[] = "Password is not valid";
                $resp['msg']  = $error;
                $resp['MEM_STATUS']   = false;    
                echo json_encode($resp);
                exit; 
           }
          session_start();
          $_SESSION['MEM_ID'] = $row[0]['MEM_ID'];
          $resp['redirect']    = "dashboard.php";
          $resp['MEM_STATUS']      = true;    
          echo json_encode($resp);
          exit;    
       } else {
          $error[] = "Email does not match";
          $resp['msg']  = $error;
          $resp['MEM_STATUS']   = false;    
          echo json_encode($resp);
          exit;    
     } 
?>