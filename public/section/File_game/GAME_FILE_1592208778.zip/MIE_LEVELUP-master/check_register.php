<?php

require_once __DIR__.'/config/connect.php'; 
 
$MEM_EMAIL = $_REQUEST[MEM_EMAIL];
$sql = "SELECT * FROM MIE_MEMBER WHERE MEM_EMAIL='$MEM_EMAIL'";
$result = mysqli_query($conn, $sql);
if(mysqli_num_rows($result) == 0){
	echo "true,&nbsp;<span style='color:green'><font style='font-size: 13px;'>Email is working</font></span>";
}else{ 
	echo "false,&nbsp;<span style='color:red'><font style='font-size: 13px;'>Email is already exist !</font></span>";
}
?>
