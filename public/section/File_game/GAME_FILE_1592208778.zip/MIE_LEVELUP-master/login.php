<?php 
session_start();
require_once __DIR__.'/config/connect.php'; 

if(isset($_POST['button'])){
    $MEM_EMAIL = $conn->real_escape_string($_POST['MEM_EMAIL']);
    $MEM_PASSWORD = $conn->real_escape_string($_POST['MEM_PASSWORD']);
    $MEM_PASSWORD = md5($MEM_PASSWORD);  

    $sql = "SELECT * FROM `MIE_MEMBER` WHERE `MEM_EMAIL` = '".$MEM_EMAIL."' AND `MEM_PASSWORD` = '".$MEM_PASSWORD."'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    if(!$row){
            echo "<script>";
            echo "swal({
                    title: 'Good job!',
                    text: 'You clicked the button!',
                    icon: 'success',
                    button: 'Aww yiss!',
                  });";
            echo "window.location.href='login.php';";
            echo "</script>";
        }else{
            $_SESSION["MEM_ID"] = $row["MEM_ID"];
            $_SESSION["MEM_FIRSTNAME"] = $row["MEM_FIRSTNAME"];
            $_SESSION["MEM_LASTNAME"] = $row["MEM_LASTNAME"];
            $_SESSION["MEM_TYPE_ID"] = $row["MEM_TYPE_ID"];

            session_write_close();
            }

        if($row > 0){
            if($row["MEM_TYPE_ID"] == "1"){
                header("location:index.php");
            }
            if($row["MEM_TYPE_ID"] == "2"){
                header("location:index.php");
            }
            if($row["MEM_TYPE_ID"] == "3"){
                header("location:index.php");
            }
        } 
    }
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <?php require_once __DIR__.'/template/head.php'; ?>
        <title>LevelUp : Login </title>
    </head>
    <body>
        <header class="header">
            <nav class="navbar navbar-expand-lg navbar-light py-3">
                <div class="container">
                    <a href="#" class="navbar-brand">
                        <!-- <img src="pic/levelup.png" alt="logo" width="150"> -->
                    </a>
                </div>
            </nav>
        </header>
        <br><br>
        <br><br><br><br><br><br><br><br><br><br>

        <div class="container">
            <div class="row py-5 mt-4 align-items-center">
                <div class="col-md-5 pr-lg-5 mb-5 mb-md-0">
                    <img src="pic/levelup.png" alt="" class="img-fluid mb-3 d-none d-md-block">
                </div>
                <div class="col-md-7 col-lg-6 ml-auto">
                    <form action="#" method="POST" enctype="multipart/form-data">
                        <div class="row">
                            <div class="input-group col-lg-12 mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-white px-4 border-md border-right-0">
                                        <i class="fa fa-envelope text-muted"></i>
                                    </span>
                                </div>
                                <input id="MEM_EMAIL" type="email" name="MEM_EMAIL" placeholder="Email Address" class="form-control bg-white border-left-0 border-md" required>   
                            </div>
                            <div class="input-group col-lg-12 mb-4">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-white px-4 border-md border-right-0">
                                        <i class="fa fa-lock text-muted"></i>
                                    </span>
                                </div>
                                <input id="MEM_PASSWORD" type="password" name="MEM_PASSWORD" placeholder="Password" class="form-control bg-white border-left-0 border-md" required>
                            </div>
                            <div class="input-group col-lg-12 mb-4">
                                <div class="input-group-prepend">
                                    <span id="msg1"></span>
                                </div>
                            </div>
                            <div class="form-group col-lg-12 mx-auto mb-2">
                                <input type="submit" name="button" id="submit" value="Login" class="btn btn-danger btn-block py-2">
                            </div>
                            <div class="text-center w-100">
                                <p class="text-muted font-weight-bold">Already Registered? <a href="register.php" class="text-primary ml-2">Register</a></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <style>
        #error_notif {
        display:none;
        }
        </style>
        <?php require_once __DIR__.'/template/script.php'; ?>
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <script>
        $(document).ready(function(){
            $("#MEM_EMAIL").change(function(){
                var flag;
                $.ajax({
                    url: "check_login.php",
                    data: "MEM_EMAIL=" + $("#MEM_EMAIL").val(),
                    type: "POST",
                    async:false,
                    success: function(data, status) { 
                    var result = data.split(",");
                    flag = result[0];
                    var msg = result[1];
                    $("#msg1").html(msg);
                    },
                    error: function(xhr, status, exception) { alert(status); }
                });
                return flag;
            });
        });
        </script>
    </body>
</html>