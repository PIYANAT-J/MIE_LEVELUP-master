<html>
<head>
<title>ThaiCreate.Com Tutorial</title>
</head>
<body>
<?
	if($_FILES["filUpload"]["name"] != "")
	{
		
		//*** Read file BINARY ***'
		$fp = fopen($_FILES["filUpload"]["tmp_name"],"r");
		$ReadBinary = fread($fp,filesize($_FILES["filUpload"]["tmp_name"]));
		fclose($fp);
		$FileData = addslashes($ReadBinary);

		//*** Insert Record ***//
		$objConnect = mysql_connect("localhost","root","root") or die("Error Connect to Database");
		$objDB = mysql_select_db("mydatabase");
		$strSQL = "INSERT INTO files ";
		$strSQL .="(Name,FilesName) VALUES ('".$_POST["txtName"]."','".$FileData."')";
		$objQuery = mysql_query($strSQL);		

		echo "Copy/Upload Complete<br>";

	}
?>
<a href="PageUploadToMySQL3.php">View files</a>
</body>
</html>