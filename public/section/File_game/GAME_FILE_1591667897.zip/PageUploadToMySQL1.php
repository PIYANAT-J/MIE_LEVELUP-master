<html>
<head>
<title>ThaiCreate.Com Tutorial</title>
</head>
<body>
	<form name="form1" method="post" action="PageUploadToMySQL2.php" enctype="multipart/form-data">
	Name : <input type="text" name="txtName"><br>
	Picture : <input type="file" name="filUpload"><br>
	<input name="btnSubmit" type="submit" value="Submit">
	</form>
</body>
</html>