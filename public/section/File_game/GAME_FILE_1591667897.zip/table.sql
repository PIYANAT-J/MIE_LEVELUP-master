CREATE TABLE `files` (
  `FilesID` int(4) NOT NULL auto_increment,
  `Name` varchar(100) NOT NULL,
  `FilesName` blob NOT NULL,
  PRIMARY KEY  (`FilesID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8;