<html>
<head>
<title>ThaiCreate.Com Tutorial</title>
</head>
<body>
<?

		//*** Update Record ***//
		$objConnect = mysql_connect("localhost","root","root") or die("Error Connect to Database");
		$objDB = mysql_select_db("mydatabase");

		$strSQL = "UPDATE files ";
		$strSQL .=" SET NAME = '".$_POST["txtName"]."' WHERE FilesID = '".$_GET["FilesID"]."' ";
		$objQuery = mysql_query($strSQL);		
	
	if($_FILES["filUpload"]["name"] != "")
	{

			//*** Read file BINARY ***'
			$fp = fopen($_FILES["filUpload"]["tmp_name"],"r");
			$ReadBinary = fread($fp,filesize($_FILES["filUpload"]["tmp_name"]));
			fclose($fp);
			$FileData = addslashes($ReadBinary);			

			//*** Update New File ***//
			$strSQL = "UPDATE files ";
			$strSQL .=" SET FilesName = '".$FileData."' WHERE FilesID = '".$_GET["FilesID"]."' ";
			$objQuery = mysql_query($strSQL);		

			echo "Copy/Upload Complete<br>";

	}
?>
<a href="PageUploadToMySQL3.php">View files</a>
</body>
</html>