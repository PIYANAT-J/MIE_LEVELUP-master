<?php
 /**
 * The ADMIN functions for SKT Ele Local Business Lite
 *
 * Stores all the admin functions of the template.
 *
 * @package SKT Ele Local Business Lite
 * 
 * @since SKT Ele Local Business Lite 1.0
 */
 


/**************** LOAD RAW CSS & JS ON BACKEND ****************/
add_action('admin_head', 'complete_editor_fix');

function complete_editor_fix() {}