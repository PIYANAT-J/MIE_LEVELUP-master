<?php
global $complete;
?>
<?php include( get_page_template() ); ?>