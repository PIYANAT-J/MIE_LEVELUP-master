@extends('layouts.dashboard')

@section('url')
report
@endsection

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
    <!-- <script src="js/app.js"></script> -->

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <!-- <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet"> -->

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <!-- <link rel="stylesheet" href="css/app.css"> -->
    <!-- <link rel="stylesheet" type="text/css" href="css/app.css"> -->



</head>

@section('content')

<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-2 text-gray-800">รายงาน</h1>
    <p class="mb-4">รายงานผลข้อมูลการแลกเงินและการเติมเงินของแต่ละวัน </p>

    <!-- DataTales Example -->
    <div class="card shadow mb-4">

        <div class="card-body">

            {{-- <div class="row">
                <button type="button" id="exportexel" class="btn btn-primary mb-2 ml-2">Export to excel</button>

            </div> --}}

            <div class="row">
                <label for="datepicker" class="col-1 text-left">Date from: </label>
                <div class="col-2 mr-auto mb-2">
                    <input type="text" name="datepicker" id="datepicker" class="form-control form-control-sm">
                </div>

                <label for="datepicker" class="col-1 text-left">Date to: </label>
                <div class="col-2 mr-auto mb-2">
                    <input type="text" name="datepickerto" id="datepickerto" class="form-control form-control-sm">
                </div>

                <label for="fillter" class="col text-right">Filter: </label>
                <div class="col-4 ml-auto mb-2">
                    <select name="fillter" class="form-control form-control-sm">
                        <option value="all">--view all--</option>
                        <option value="topup">--topup---</option>
                        <option value="bankingtopup">|___banking---</option>
                        <option value="mobiletopup">|___mobilebanking---</option>
                        <option value="exchange">--exchange--</option>
                    </select>
                </div>
            </div>

            <div class="table-responsive">
                <table class="table" id="dataTable" width="100%" cellspacing="0">

                    <thead>
                        <tr class="bold">
                            <!-- <th>id</th> -->
                            <th>เบอร์โทรศัพท์</th>
                            <th>ชื่อ - นามสกุล</th>

                            {{-- EXCHANGE TYPE --}}
                            @if($transaction->type == 'exchange')
                            <th> ชื่อธนาคาร </th>
                            <th> เลขบัญชี </th>
                            <th> จำนวนเครดิต </th>
                            <th> 3 % </th>
                            <th> จำนวนเงิน ( หลังหัก ) </th>
                            @endif

                            {{-- TOPUP TYPE --}}
                            @if($transaction->type == 'topup')
                            <th> จำนวนเงิน ( ก่อนหัก ) </th>
                            <th> 2.5 % </th>
                            <th> จำนวนเครดิต </th>
                            @endif

                            {{-- All TYPE --}}
                            @if($transaction->type == 'all')
                            <th> ประเภท </th>
                            <th> จำนวนเงิน </th>
                            <th> เปอร์เซนต์ </th>
                            <th> จำนวนเครดิต </th>
                            @endif

                            <th>วัน/เวลา</th>
                        </tr>
                    </thead>
                    <tbody class="" style="font-size: 0.8rem;">
                        @foreach ($transaction as $item)
                        <tr class="align-items-center">

                            <td>{{ $item['phone'] }}</td>
                            <td>{{ $item['name'] }} - {{ $item['sirname'] }}</td>

                            {{-- EXCHANGE TYPE --}}
                            @if($transaction->type == 'exchange')
                            <td> {{$item['bank_name']}} </td>
                            <td> {{$item['bookbank_number']}} </td>
                            <td> {{$item['credit']}} </td>
                            <td> {{$item['percent'] }} </td>
                            <td> {{$item['amount']}} </td>
                            @endif

                            {{-- TOPUP TYPE --}}
                            @if($transaction->type == 'topup')
                            <td> {{ $item['amount']}} </td>
                            <td> {{ $item['percent']}} </td>
                            <td> {{ $item['credit']}} </td>
                            @endif

                            {{-- ALL TYPE --}}
                            @if($transaction->type == 'all')
                            <td> {{ $item['type'] == 'exchange' ? 'แลกเครดิต' : 'เติมเครดิต'}}
                            <td> {{ $item['amount']}} </td>
                            <td> {{ $item['percent']}} </td>
                            <td> {{ $item['credit']}} </td>
                            @endif

                            <td>{{ $item['created_at']}}</td>
                        </tr>
                        @endforeach
                    </tbody>

                </table>
            </div>

        </div>
    </div>

</div>

@endsection

@section('script')



<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<script src="https://cdn.datatables.net/buttons/1.6.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.1/js/buttons.html5.min.js"></script>
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.1/css/buttons.dataTables.min.css">

<script>
    function fnExcelReport()
        {
            var tab_text="<table border='2px'><tr bgcolor='#87AFC6'>";
            var textRange; var j=0;
            tab = document.getElementById('dataTable'); // id of table

            for(j = 0 ; j < tab.rows.length ; j++) 
            {     
                tab_text=tab_text+tab.rows[j].innerHTML+"</tr>";
                //tab_text=tab_text+"</tr>";
            }

            tab_text=tab_text+"</table>";
            tab_text= tab_text.replace(/<A[^>]*>|<\/A>/g, "");//remove if u want links in your table
            tab_text= tab_text.replace(/<img[^>]*>/gi,""); // remove if u want images in your table
            tab_text= tab_text.replace(/<input[^>]*>|<\/input>/gi, ""); // reomves input params

            var ua = window.navigator.userAgent;
            var msie = ua.indexOf("MSIE "); 

            if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer
            {
                txtArea1.document.open("txt/html","replace");
                txtArea1.document.write(tab_text);
                txtArea1.document.close();
                txtArea1.focus(); 
                sa=txtArea1.document.execCommand("SaveAs",true,"Say Thanks to Sumit.xls");
            }  
            else                 //other browser not tested on IE 11
                sa = window.open('data:application/vnd.ms-excel,' + encodeURIComponent(tab_text));  

            return (sa);
        }

        
    var sel = {
            date : new Date().toISOString().slice(0,10),
            dateto : new Date().toISOString().slice(0,10),
            type : ''
        }
        
        var url = '{{Request::path()}}';
        var res = url.split('/'); 
        sel.type = url.split('/')[2] != undefined ? url.split('/')[2] : 'all';
        sel.date = url.split('/')[3] != undefined ? url.split('/')[3] : sel.date;
        sel.dateto = url.split('/')[4] != undefined ? url.split('/')[4] : sel.dateto;

        console.log(sel);

        

        $(document).ready( function () {
            $('#dataTable').DataTable({
                dom: 'Bfrtip',
                buttons: {
                    dom: {
                        button: {
                        className: 'btn btn-primary'
                        }
                    },
    
                    buttons: [
                        { 
                        extend: 'excelHtml5', 
                        text: 'Export to exel',
                        title: sel.type+'_'+sel.date+'_'+sel.dateto,
                        className: 'btn btn-primary',
                        customize: function ( xlsx ) {
                            var sheet = xlsx.xl.worksheets['sheet1.xml'];
                        
                            $('c[r=A1] t', sheet).text( 'รายงานประเภท'+sel.type+'ตั้งแต่วันที่'+sel.date+'ถึงวันที่'+sel.dateto );
                            }
                        }
                    ],
                }
                
            });
            
            $("select[name='fillter'] option[value="+sel.type+"]").attr('selected','selected');

            // $('#datepicker').val(sel.date.split('-')[2] +'/'+ sel.date.split('-')[1] +'/'+ sel.date.split('-')[0])
            $('#datepicker').val(sel.date)

            // $('#datepickerto').val(sel.dateto.split('-')[2] +'/'+ sel.dateto.split('-')[1] +'/'+ sel.dateto.split('-')[0])
            $('#datepickerto').val(sel.dateto)

            // $('#exportexel').click(function(){
            //     window.location.href = '{{url('dashboard/report/export')}}/'+sel.type+'/'+sel.date+'/'+sel.dateto;
            // })

            $('#exportexel').click(function(){
                fnExcelReport();
            })

            



        });

        var datepicker = $('#datepicker').datepicker({ dateFormat: 'yy-mm-dd' 
            });

        var datepickerto = $('#datepickerto').datepicker({ dateFormat: 'yy-mm-dd' 
        });

        datepicker.on('change',function(e){

            sel.date = datepicker.val();            
            // $('#datepicker').val(sel.date.split('-')[2] +'/'+ sel.date.split('-')[1] +'/'+ sel.date.split('-')[0])
            
            window.location.href = '{{url('dashboard/report')}}/'+sel.type+'/'+sel.date;

        });

        datepickerto.on('change',function(e){

            sel.dateto = datepickerto.val();            
            // $('#datepickerto').val(sel.dateto.split('-')[2] +'/'+ sel.dateto.split('-')[1] +'/'+ sel.dateto.split('-')[0])

            window.location.href = '{{url('dashboard/report')}}/'+sel.type+'/'+sel.date+'/'+sel.dateto;

        });

        $("select[name='fillter']").on('change', function(event) {
            event.preventDefault()
            sel.type = $(this).val()
            window.location.href = '{{url('dashboard/report')}}/'+$(this).val()+'/'+sel.date

            // if ($(this).val() === 'all') {              
            //     window.location.href = '{{url('dashboard/report/all')}}/'+sel.date
            // } else if ($(this).val() === 'topup') {
            //     window.location.href = '{{url('dashboard/report/topup')}}/'+sel.date
            // }else if ($(this).val() === 'exchange') {
            //     window.location.href = '{{url('dashboard/report/exchange')}}/'+sel.date
            // } 
        })
</script>
@endsection